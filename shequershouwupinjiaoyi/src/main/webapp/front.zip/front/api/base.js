﻿const base = {
    url : "http://localhost:8080/shequershouwupinjiaoyi/"
}
export default base
